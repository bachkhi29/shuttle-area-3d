# Shuttle Arena 3D — AF3 Pose Board và QC v0.1

Ngày 14/10/2026. **Bản giao việc cho mẫu thử 3D đầu tiên, chưa phải asset đã dựng.** Chủ dự án đã duyệt bắt đầu AF3. Đích: nhân vật nam thuận tay phải, một chuỗi ready → split-step → tiến góc lưới thuận tay → lunge → hồi vị; cú forehand overhead clear có storyboard riêng để kiểm tra kế tiếp.

## Cơ sở và giới hạn

- Video thi đấu `Axelsen_vs_LeeZiiJia.mp4` và ba clip bổ sung đã được quan sát; sheet v0.1–v0.3 ghi các mốc nhìn được. Video trận chỉ dùng tham khảo nhịp, dáng và ứng xử khi áp lực. Cú cứu cầu mất thăng bằng không phải mẫu lunge P0.
- BWF *Coaches' Manual Level 1*, Module 6: chuỗi tiến sân trước có split-step, bước di chuyển, lunge và hồi vị; chân trước/gối hướng về vùng chạm. Module 7: forehand clear chuẩn bị nghiêng người, tay không vợt nâng, tải chân sau, đẩy hông/vai và tiếp xúc cao hoặc hơi trước vai cầm vợt. Nguồn: https://www.badminton-israel.co.il/newsNdata/General/CoachEducationBWF/BWF_Coach_Manual_Level_1.pdf (trang 67–69, 117–118 theo số trang nội dung).
- Chưa có footage độc lập đủ rõ để lấy timing hoặc tọa độ 3D chính xác cho lunge và clear. Các mốc phần trăm phía dưới **là bố cục action đề xuất để thử**, không phải số đo từ vận động viên. Thời lượng cuối, chân trụ cụ thể theo góc sân, khoảng cách di chuyển và điểm contact phải điều chỉnh trên rig với cầu mô phỏng.

## A. Action P0-LUNGE-FH-01 — một nhịp tiến lưới và quay lại

**Tình huống thiết kế:** avatar nam tay phải từ vị trí giữa sân tiến tới vùng trước bên phải của chính mình, đánh một quả ở gần lưới, rồi trở lại tư thế có thể đón quả tiếp. Đây là một biến thể cụ thể, không dùng mirror tự động cho mọi góc sân.

| Pose / nhịp đề xuất | Chân và trọng tâm | Thân, vợt, đầu | Sự kiện cần đánh dấu |
|---|---|---|---|
| A0 READY / 0% | Hai bàn chân trên sàn, gối hơi chùng, hông ở giữa vùng đỡ. | Vai hướng lên lưới; đầu và mắt theo cầu; tay phải giữ vợt trước thân. | Bắt đầu action có thể nối từ idle. |
| A1 SPLIT / ~10–20% | Bước nảy ngắn nếu hợp lý, hai chân tiếp đất rộng hơn; hông hạ và sẵn sàng đẩy sang phía trước phải. | Vợt duy trì phía trước, không vung tay lớn. | `split_land`: kiểm tra cả hai chân có vị trí hợp lý; không đặt thời gian cố định theo video dạy. |
| A2 TRAVEL / ~20–45% | Di chuyển ngắn bằng bước dẫn/chasse theo khoảng cách, chân phải hướng vào vùng trước; từng chân nhấc và đặt rõ. | Thân hơi nghiêng theo hướng di chuyển; đầu nhìn vùng cầu. | Root di chuyển theo đường sân, không trượt gót khi bàn chân đang chịu lực. |
| A3 LUNGE / ~45–65% | Chân phải bước dài ra trước và đỡ trọng lượng; gối/mũi chân phải cùng hướng; chân trái ở sau cân bằng. | Vợt phải vươn trước vào vùng cầu, tay trái đối trọng; thân không gập sập vô lý. | `right_foot_plant` và `contact_window` phải được kiểm tra theo cầu mô phỏng. |
| A4 PUSH BACK / ~65–85% | Chân phải đẩy khỏi mặt sàn; chuyển lực sang chân trái, thu khoảng cách hai chân. | Vợt rút về vị trí chờ, thân nâng vừa đủ. | Không đảo phát toàn bộ A2–A3; có động tác đạp lùi thật. |
| A5 RECOVER / ~85–100% | Chasse/bước lùi về vùng có thể phản ứng; hai chân kết thúc trong thế sẵn sàng. | Vai quay về phía lưới, vợt trở lại trước thân. | `ready_reentry`: blend được với ready mà không giật vị trí. |

**Thiết kế blend:** có thể tách thành split, travel, lunge/contact, recovery nếu hệ game cần đổi hướng giữa chừng. Bảng phần trăm mô tả một action thử liên tục để QC; chưa khóa cách cắt clip hay root motion. Không yêu cầu cầu luôn đúng một tọa độ tĩnh; điểm chạm phải hiệu chỉnh theo hệ aim assist đã chốt.

## B. Storyboard sáu pose P0-CLEAR-FH-01

| Pose | Cơ thể và chân | Vợt/cầu | Kiểm tra |
|---|---|---|---|
| C0 READY | Vị trí có thể lùi về cuối sân, gối mềm. | Vợt trước thân; mắt theo cầu bay tới. | Transition từ ready. |
| C1 TURN/LOAD | Xoay thân nghiêng ngang, lùi/chỉnh chân; tải lên chân sau; tay trái giơ hướng cầu. | Tay phải/vợt chuẩn bị sau vai. | Không xoắn vai khi hông/đầu gối vẫn bị khóa hướng lưới. |
| C2 BACKSWING | Chân sau bắt đầu đẩy, hông và vai nối chuyển động; khuỷu tay phải đi lên. | Đầu vợt đi sau và trên đầu, không xuyên lưng. | Silhouette nhìn từ sau và bên. |
| C3 CONTACT | Thân vươn lên; vai phải ở dưới cánh tay tiếp xúc. | **Mặt dây vợt** gặp cầu phía trên hoặc hơi trước vai phải. | Cầu rời vợt đi cao/sâu về cuối sân đối phương; đo sai số contact sau khi có rig. |
| C4 FOLLOW | Hông/vai quay tiếp, vợt theo đà; chân sau đổi lên trước nếu chọn biến thể scissor. | Vợt đi xuống tự nhiên, không nhảy khung. | Foot plant và cân bằng. |
| C5 RECOVER | Chân đặt lại để di chuyển tiếp, không đứng cứng cuối động tác. | Vợt trở về trước thân. | Blend sang ready/di chuyển. |

Không dùng clip `Overhead smash and variations` rồi đổi hướng cầu để gọi đó là clear. BWF mô tả clear đưa cầu từ cuối sân mình tới cuối sân đối phương; phải kiểm tra cả đường cầu lẫn tư thế người.

## C. Tiêu chí nghiệm thu mẫu thử 3D

| Gate | Bằng chứng cần giao | PASS khi | FAIL khi |
|---|---|---|---|
| Rig | File nguồn nhân vật/rig, bản đồ xương, tay cầm vợt | Nam tay phải, tỷ lệ nhất quán, cổ tay/vợt theo đúng tay | Vợt rời tay, biến dạng gối/vai cản động tác |
| Trọng tâm/chân | Video góc sau và bên ở tốc độ thường/chậm; mốc chân chạm sàn | Các bước có nhấc/đặt, chân trụ không trượt rõ, gối không xoắn/xuyên sàn | Root lướt trên sân, gối gãy, hồi vị tức thời |
| Contact | Ảnh frame trước/trong/sau cú đánh, vị trí cầu và mặt dây | Vợt thực sự vào vùng cầu, thời điểm phù hợp động tác; clear bay cao/sâu | Contact bằng tay hoặc không có cầu ở vùng vợt |
| Chuyển trạng thái | Xem A0→A5 ít nhất hai vòng và A5→ready | Không nhảy pose hoặc đổi vị trí đột ngột | Kết thúc bị khóa, mất thăng bằng hoặc foot snap |
| Xuất/nhập | `.blend` và `.glb` cùng bản xem sau nhập lại | Giữ đủ mesh, rig, vợt, action và tỷ lệ | Mất animation, sai scale hoặc vợt lệch tay |

Chưa tự đặt ngưỡng cm/ms: cần scale nhân vật và baseline thử nghiệm trước, sau đó ghi số đo và trình ngưỡng QC để duyệt. Mọi gate chưa có asset đều đang **NOT TESTED**, không được đánh PASS theo storyboard.

## D. Tình trạng môi trường và đường thực hiện

Trong workspace hiện không có Blender, file `.blend`, rig nam, model vợt hay `.glb` nguồn. Có OpenSCAD nhưng không thay thế được rig xương và pipeline animation Blender. Vì ràng buộc đã chốt là **không viết code**, không tạo scene/GLB bằng script tự sinh để giả làm mẫu Blender. Việc cần mở khóa AF3 là một môi trường Blender có thể thao tác trực tiếp và một rig/nhân vật có quyền sử dụng. Ưu tiên công cụ miễn phí và thử trên asset hợp lệ; không mua hay đăng ký trả phí.

Sau khi có môi trường/rig: dựng A0–A5, ghi video hai góc, chỉnh chân/contact, rồi mới dựng C0–C5 và xuất GLB thử. Chủ dự án chỉ cần review clip QC; không phải thao tác Blender.
