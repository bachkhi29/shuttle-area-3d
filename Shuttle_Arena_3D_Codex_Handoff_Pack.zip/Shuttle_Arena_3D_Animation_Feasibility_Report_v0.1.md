# Shuttle Arena 3D Animation Feasibility Report v0.1

Ngày: 13 tháng 10 năm 2026. Người nhận: chủ dự án Shuttle Arena 3D.

**Trạng thái: nghiên cứu và kế hoạch để duyệt. Chưa chứng minh pipeline bằng asset thực nghiệm.**

Đề xuất tiếp tục theo hybrid pipeline đã chốt: phân tích video trước, dùng thư viện làm nền khi phù hợp, thử video mocap có điều kiện và chỉnh trong Blender. Điểm khó nhất cần chứng minh là sự đồng bộ giữa chân trụ, chuyển động toàn thân, mặt vợt và contact; chất lượng model hoặc ánh sáng không giải quyết được các lỗi này.

Hai video chưa truy xuất được để xem từng khung hình trong phiên nghiên cứu này. Không có kết luận về vận động viên, tay thuận, kỹ thuật xuất hiện, timestamp, fps hay chất lượng mocap của từng video. Có thể duyệt kế hoạch nghiên cứu; chưa có căn cứ duyệt sản xuất animation hàng loạt.

Phạm vi đã thực hiện: đọc đặc tả, đối chiếu quyết định, nghiên cứu tài liệu công cụ và thiết kế kế hoạch. Không viết mã nguồn game, tạo repository, tạo asset Blender, đăng ký dịch vụ, upload footage hoặc deploy. GDD/TDD gốc được giữ nguyên.

## 1 Nguồn đặc tả và đối chiếu

Nguồn chính đã đọc: Shuttle_Arena_3D_GDD_TDD_v1.1_Animation_Feasibility(2).docx, 20 trang, tạo ngày 13/10/2026; các mục A4–A7, B1–B5, C1–C7, D1–D7 và E1–E14. Báo cáo này là tài liệu bổ sung, không thay thế baseline.

Các quyết định trong handoff khớp định hướng v1.1: realistic 3D, arcade aim assist, camera sau sân, nam tay phải, Quick Match và Training, menu 11/15/21, hybrid animation, P1 replay/presets/statistics/history và công nghệ còn là ứng viên.

| Mã | Vị trí trong v1.1 | Điểm cần xử lý | Đề xuất chờ duyệt |
|---|---|---|---|
| C01 | Trang 2, hàng Chưa chốt | Chứa cả quyết định đã chốt; dễ đọc sai trạng thái | Tách LOCKED và OPEN khi có yêu cầu cập nhật tài liệu |
| C02 | C6 trang 10 và E5–E6 trang 17 | C6 dùng 5 mốc; E5 dùng 6 mốc | Chuẩn hóa 6 mốc; động tác không có contact ghi N/A |
| C03 | C2 trang 9 và A4/A7 trang 3–4 | 8–12 clip nền tảng chưa chứng minh đủ biến thể footwork; net/drive có trong Shot System nhưng thiếu trong danh sách P0 rút gọn | Đếm theo action thực tế; đề nghị net cơ bản P0 và drive P1, chủ dự án duyệt |
| C04 | D4 trang 13 và E1 trang 15 | Hai hệ D và DR cùng tồn tại, mã không tương đương số | Lập bảng đối chiếu theo nội dung; không tự đổi mã |
| C05 | D2 trang 12 | Bảng 9 ngày nói rõ không phải deadline nhưng có cả engine/code trong giai đoạn đầu | Dùng milestone và gate làm kế hoạch điều hành; bảng ngày chỉ là lịch sử tham khảo |
| C06 | A5/E2 trang 4 và 16 | Chọn 11/15/21 đã chốt; cấu hình, mặc định và nhãn luật cụ thể chưa được chủ dự án khóa toàn bộ | Giữ lựa chọn; rà soát luật chính thức ở milestone Rules, ngoài phạm vi animation |

Không phát hiện xung đột buộc phải thay đổi quyết định đã chốt. C03 là khoảng trống về phạm vi cần phê duyệt; các điểm khác chủ yếu là sự nhất quán hoặc trạng thái. Các tuyên bố thời điểm hiệu lực luật trong v1.1 không được coi là đã xác minh lại bởi báo cáo này.

High-Fidelity Realistic 3D là định hướng sản phẩm. Việc polish hình ảnh ở P1 không cho phép P0 bỏ qua tính đúng của footwork hoặc contact. Engine, root motion, model và ngưỡng QC vẫn OPEN theo E1.

## 2 Đánh giá hai video

| Nguồn | Trạng thái truy cập | Quan sát trực tiếp | Kết luận hiện tại |
|---|---|---|---|
| V01 https://youtu.be/zYqgJo1L5uM | Không lấy được nội dung để xem frame | Không có | Chờ clip/frame; không chấm điểm |
| V02 https://youtu.be/VD8ZfEW94mk | Không lấy được nội dung để xem frame | Không có | Chờ clip/frame; không xếp hạng so với V01 |

Không tìm kiếm ra tiêu đề hay transcript rồi coi đó là phân tích chuyển động. Chưa thể quyết định video nào tốt hơn hoặc đoạn nào có overhead clear. Timestamp do chủ dự án cung cấp chỉ giúp định vị; vẫn cần nhìn được frame để phân tích.

### Dữ liệu cần bổ sung

Ưu tiên MP4 ngắn mà chủ dự án được phép cung cấp/xử lý. Đợt đầu cần ba mẫu, có thể lấy từ một hoặc cả hai nguồn: ready và split-step khoảng 2–4 giây; lunge và recovery khoảng 3–6 giây; forehand overhead clear khoảng 3–6 giây. Đây là độ dài tuyển mẫu đề xuất, không phải timestamp hoặc thời lượng quan sát từ hai video.

Nếu không gửi MP4, cung cấp chuỗi frame gốc liên tiếp có timestamp/frame index, giữ cả chân và tay. Với contact, gửi thêm vùng frame trước và sau thời điểm nghi chạm cầu. Sáu ảnh mốc giúp đọc tư thế nhưng chưa đủ xác minh nhịp liên tục, foot drift hoặc chuyển động giữa hai ảnh. Ghi tên file, tay thuận nếu biết, nguồn, fps nếu biết, việc đã làm chậm clip và điều kiện sử dụng. Thiếu fps ghi UNKNOWN.

Nếu quay mới: máy cố định, ánh sáng đủ, toàn thân trong khung, có mặt sân và vợt; ưu tiên hai góc sau sân và bên hông. Hai góc quay của cùng một lần thực hiện phải đồng bộ mới dùng để tái dựng đa góc. Hai lần thực hiện khác nhau chỉ là reference bổ sung. Không cần quay smash hết lực để chứng minh pipeline ban đầu.

### Rubric theo E4

Chấm 0–2 cho góc quay, toàn thân, che khuất, độ nét, mốc động tác và quyền xử lý; tổng 0–12. Ghi N/A nếu chưa nhìn được, không biến UNKNOWN thành 0. Theo v1.1, 8–12 là ứng viên reference; mocap còn cần quyền xử lý 2/2 và góc/toàn thân/che khuất phù hợp. Tổng cao không bù được việc thiếu quyền upload hoặc contact bị khuất. Thêm mục fps gốc, motion blur quanh contact, vợt/cầu có nhìn thấy và slow motion đã được tạo như thế nào; chúng chưa thay đổi rubric chính thức.

Phân loại kết quả: REFERENCE ONLY, MOCAP CANDIDATE hoặc REJECT FOR THIS PURPOSE. Một clip có thể tốt cho footwork nhưng bị loại khỏi nhiệm vụ phân tích contact.

## 3 Kế hoạch quan sát mười kỹ thuật

Các hàng sau là câu hỏi cần kiểm chứng, không phải kết quả xem V01/V02 hoặc kết luận về một kỹ thuật duy nhất đúng cho mọi tình huống.

| Kỹ thuật | Dữ kiện cần nhìn | Điều không được tự suy ra | Ảnh hưởng tới thiết kế |
|---|---|---|---|
| Ready Stance | Độ rộng chân tương đối, thân, tay vợt, hướng nhìn | Trọng tâm 3D và lực trên mỗi chân | Pose bắt đầu và kết thúc clip |
| Split-step | Khởi phát, chân rời/chạm sàn, thứ tự tiếp đất, bước tiếp theo | Thời điểm tiếp đất luôn cố định với mọi cú của đối phương | Event chân và chuyển sang di chuyển |
| Chasse Step | Chân dẫn, chân theo, số bước, khoảng cách giữa chân | Một loop chạy ngang thông thường là đủ | Biến thể trái/phải và tốc độ |
| Cross-step | Chân nào bắt chéo, hướng hông/thân, tình huống sử dụng | Chasse và cross-step thay thế tùy ý | Clip riêng và điều kiện chọn |
| Forward Lunge | Chân trụ cuối, góc thân, bàn chân, thời điểm vươn vợt | Phía trái sân đồng nghĩa chân trái trụ | Lunge hai vùng sân, không mirror mù |
| Recovery Footwork | Chân đẩy, bước đầu sau cú đánh, hướng trở về | Hồi vị trí là phát ngược lunge hoặc luôn về tâm hình học sân | Clip recovery và điểm kết thúc động |
| Forehand Overhead Clear | Chuẩn bị, xoay thân, tay không vợt, đường vợt, tiếp xúc và kết thúc | Góc cổ tay hoặc tốc độ vợt chính xác khi blur | Mẫu thử chuyển động đầu tiên |
| Smash | Khác biệt với clear ở nhịp và đường vợt, có/không bật nhảy, tiếp đất | Tăng tốc clip clear tự tạo được smash chân thực | Standing smash P0; jump smash P1 |
| Defensive Lift | Độ thấp của cầu, mặt vợt, forehand/backhand, chân trụ | Tư thế giống overhead clear | Hai biến thể cơ bản cho vùng tiếp xúc thấp |
| Net Shot | Tầm vươn, mặt vợt, biên độ ngắn, recovery | Cổ tay chính xác hoặc hướng cầu đủ đo 3D từ một góc | Contact tinh và biến thể FH/BH |

Nhận xét mỗi lần phải mang nhãn OBSERVED, INFERRED hoặc UNKNOWN. OBSERVED chỉ nói điều nhìn thấy; ví dụ bàn chân phải chạm sàn ở frame X. Kết luận chân đó chịu toàn bộ lực là INFERRED nếu không có dữ liệu lực. Nếu chỉ thấy vợt đi gần cầu, ghi khoảng contact khả dĩ, không khẳng định frame impact thật.

## 4 Danh mục animation đề xuất

P0 là mức bao phủ tối thiểu để nghiệm thu gameplay sau này; không phải tất cả đều sản xuất trong thử nghiệm đầu tiên. Mỗi biến thể cần action/kiểm chứng riêng nếu không tái sử dụng an toàn. Tên trái/phải chỉ vùng di chuyển trong hệ local của nhân vật, không chỉ tay cầm vợt.

| Nhóm | P0 đề xuất | P1 đề xuất | Future |
|---|---|---|---|
| Sẵn sàng | Ready idle, chuẩn bị giao cầu/nhận cầu, split-step và chuyển vào di chuyển | Idle biến thể, chỉnh tư thế tinh | Cá tính vận động viên |
| Di chuyển | Chasse trái/phải; cross-step trái/phải; tiến/lùi; tăng tốc, dừng, đổi hướng | Biến thể chéo và tốc độ mở rộng, rear-court/scissor chuyên biệt | Motion matching mở rộng |
| Lunge | Hai vùng trước trái/phải với chân trụ được xác minh | Lunge ngang, sâu và cứu cầu muộn | Dive và cứu cầu cực hạn |
| Recovery | Hồi từ hai vùng lunge và từ động tác cuối sân; transition về ready | Recovery theo tình huống chiến thuật phong phú | Bộ cho đánh đôi |
| Serve | Serve ngắn và dài cơ bản, có contact và chuyển sang ready | Flick serve và biến thể phong cách | Nhiều kiểu giao của các nhân vật |
| Overhead | Forehand clear, drop, standing smash; chuẩn bị và kết thúc đủ dùng | Round-the-head, backhand clear/drop, jump smash | Deception/slice chuyên sâu |
| Đánh thấp | Defensive lift forehand/backhand | Block và defensive drive | Cứu cầu khó nhiều tư thế |
| Lưới | Net forehand/backhand cơ bản, chờ duyệt phân hạng P0 | Net kill, spin/tumbling net | Deception ở lưới |
| Drive | Chờ quyết định phạm vi; đề xuất P1 | Forehand/backhand drive | Trao đổi đôi tốc độ cao |
| Lỗi và kết thúc | Đánh hụt/follow-through hợp lý; hết pha trở về trạng thái hợp lệ | Phản ứng thắng/thua ngắn | Celebration, cutscene |

Không đặt con số 8–12 clip thành trần bắt buộc. Loop locomotion, one-shot, transition và shot variant là các loại khác nhau; một mục như lunge có thể cần nhiều action. Manifest sẽ xác định tổng sau khi biết rig, coverage và khả năng blend.

Đề xuất bộ chứng minh M1 gồm: ready/split-step, forward lunge/recovery và forehand overhead clear. Smash là kiểm tra tiếp theo sau khi clear đạt, chưa cần jump smash. Một clear đứng yên thành công chỉ chứng minh nhánh chuyển động đó, chưa chứng minh toàn bộ locomotion.

AI và người chơi dùng chung rig, motor và vùng động tác hợp lệ. Khó hơn không đồng nghĩa tăng tốc animation tùy ý đến mức mất chân trụ hoặc thiếu follow-through. Đây là yêu cầu thiết kế để bảo toàn tính nhất quán, chưa là kết quả playtest.

## 5 Template Motion Reference Sheet

Một sheet cho một clip và một mục tiêu. Chưa có sheet đã điền bằng dữ kiện của V01/V02.

| Trường | Nội dung mẫu để điền |
|---|---|
| Reference ID và phiên bản | REF CLEAR FH 001, v01 |
| Người phân tích và ngày | __ |
| Nguồn | URL, tên file gốc, tên người quay/chủ sở hữu nếu biết |
| Điều kiện sử dụng | Xem phân tích __; lưu/cắt __; upload bên thứ ba __; output dùng trong game __ |
| Metadata | Độ phân giải __; fps gốc __; constant/variable/unknown __; đã slow motion __ |
| Khoảng nguồn | Timecode đầu __; cuối __; frame index __; offset clip so với nguồn __ |
| Chủ thể | Nam __; thuận tay phải __; căn cứ __ |
| Góc quay | Rear/side/broadcast __; chuyển camera __; che khuất __ |
| Mục tiêu | Footwork/contact/retarget __ |
| Đơn vị và scale | Chưa có scale 3D / đã hiệu chuẩn __ |
| Phân loại | Reference only / mocap candidate / reject __ |
| QC | Sáu mục rubric __; lý do __ |
| Kết luận | Có thể kết luận __; không thể kết luận __; cần bổ sung __ |

| Mốc | Timecode nguồn | Frame clip | Chân và thân quan sát được | Vợt và cầu | Nhãn và độ tin cậy |
|---|---|---|---|---|---|
| READY | __ | __ | __ | __ | __ |
| SPLIT hoặc LOAD | __ | __ | __ | __ | __ |
| MOVE hoặc ROTATE | __ | __ | __ | __ | __ |
| CONTACT | __ hoặc khoảng __ | __ | __ | __ | __ |
| FOLLOW THROUGH | __ | __ | __ | __ | __ |
| RECOVERY | __ | __ | __ | __ | __ |

Footwork không có cú đánh dùng mốc PLANT thay CONTACT và ghi contact N/A. Ghi các khoảng chân trụ [frame đầu, frame cuối], chân nào, heel/toe pivot và vùng bị khuất; không khóa bàn chân qua toàn bộ bước.

Mỗi sheet kèm sáu hình mốc hoặc vị trí trống, ghi chú liên tục quanh contact/plant và đề xuất sửa. Motion estimation sinh ra dữ liệu riêng, không đổi nhãn của frame bị khuất thành OBSERVED.

## 6 Phương pháp trích xuất và giới hạn

### Nhánh A Reference và dựng/chỉnh tay

Xem clip, đánh dấu mốc, dựng pose chủ đạo và chỉnh đường chuyển động trong Blender. Phù hợp footage thiếu dữ liệu 3D hoặc có camera broadcast; giữ quyền kiểm soát vợt và chân trụ. Đổi lại tốn thời gian và cần đánh giá từ nhiều góc để tránh chỉ đẹp ở một góc. Thư viện generic hỗ trợ idle/locomotion, không được mặc định là động tác cầu lông chính xác.

### Nhánh B Video mocap một camera

Chỉ thử khi footage và quyền xử lý đạt gate. Dữ liệu xương được tạo từ ước lượng hình ảnh, retarget sang rig đích rồi cleanup. Một video 2D không xác định duy nhất toàn bộ chuyển động 3D: chiều sâu, phần khuất, xoay quanh trục xương và camera movement dễ gây sai lệch. Bộ ước lượng cơ thể không tự cung cấp quỹ đạo vợt/cầu đáng tin.

Crop giữ người trong khung có thể làm mất hoặc bóp méo chuyển động tịnh tiến. Ổn định hình ảnh không tạo ra chiều sâu đã thiếu. Slow motion/nội suy không tạo thêm bằng chứng contact; video 30 fps có khoảng giữa các frame xấp xỉ 33,3 ms, 60 fps xấp xỉ 16,7 ms. Sai số này và blur phải được ghi; không dùng số frame suy diễn làm ground truth.

DeepMotion khuyến nghị camera đứng yên, thấy toàn thân và tránh che khuất; hướng dẫn chính thức nêu camera chuyển động/zoom/cắt góc ảnh hưởng tracking. Do vậy broadcast chỉ là ứng viên có điều kiện, chưa đủ để chọn mocap ngay [S3]. Không áp dụng các đoạn hướng dẫn cũ về số người cho mọi tính năng hiện tại của dịch vụ.

### Nhánh C Mocap nhiều camera quay mới

Nếu có thể tự quay nhiều góc đồng bộ và hiệu chuẩn, thử công cụ đa camera như FreeMoCap. Cần khung hình cùng thời điểm, dữ liệu hiệu chuẩn và chất lượng quay; không thay thế bằng hai clip khác rally. Phần mềm miễn phí không đồng nghĩa không tốn công lắp đặt, thiết bị hoặc cleanup [S4].

### Quy tắc chọn nhánh

Đầu tiên phân tích reference. Nếu kỹ thuật/footage không đủ rõ, bổ sung dữ liệu thay vì cố mocap. Nếu đủ reference nhưng không đủ mocap, chọn A. Nếu đủ footage, quyền và định dạng xuất, so sánh A với B trên cùng một động tác. Nếu B mất nhiều thời gian sửa hơn A hoặc sai contact liên tục, loại B cho loại động tác đó. Không loại toàn bộ hybrid pipeline chỉ vì một nguồn video thất bại.

Không suy ra lực, mô-men khớp, vận tốc 3D chính xác hoặc thông số sức khỏe từ video một góc chưa hiệu chuẩn. Chỉ dùng phép đo 2D trong phạm vi hình chiếu. Vạch sân giúp định vị trên mặt phẳng sân, không tự giải được độ cao cổ tay/vợt.

## 7 Pipeline thiết kế

1. **Source intake:** lưu metadata, quyền và mục tiêu. Đầu ra: source register. Gate: truy cập được và biết giới hạn xử lý.
2. **Reference breakdown:** timecode, sáu mốc, plant intervals, vùng contact khả dĩ. Đầu ra: sheet có nhãn tin cậy. Gate: dữ liệu đủ cho đúng mục tiêu.
3. **Rig chuẩn:** nam tay phải, tỷ lệ thực tế, rest pose, root và xương biến dạng; kiểm tra vai/cổ tay/hông/gối. Đầu ra: rig specification và asset manifest. Gate: pose không biến dạng nghiêm trọng.
4. **Base motion hoặc raw mocap:** giữ nguồn gốc và fps, không ghi đè; quay/dịch skeleton theo quy ước có ghi lại. Gate: đủ chuyển động liên tục để chỉnh.
5. **Retarget:** đối chiếu pelvis/spine/head/clavicle/arm/hand/leg/foot/toe; xử lý rest pose, bone orientation và chênh tỷ lệ. Đầu ra: bone mapping và action trên rig đích. Gate: không lật bên, không biến dạng rõ.
6. **Cleanup:** sửa trọng tâm thể hiện bằng tư thế, plant, vai/hông/khuỷu/cổ tay; giữ pha tải lực và kết thúc tự nhiên. Gate: có thể đọc rõ ready, chuẩn bị, contact, recovery ở nhiều góc.
7. **IK và vợt:** đặt target chân theo plant interval, pole target hướng gối/khuỷu; gắn vợt vào socket tay phải với offset được ghi. Sửa cả mặt vợt, không chỉ vị trí tay. Gate: không bẻ tay hoặc kéo dài chi để chạm target.
8. **Action authoring:** đặt tên, thời lượng, loop/one-shot, event contact và foot events; định nghĩa cửa sổ blend và giới hạn chỉnh hướng. Gate: không blend phá plant/contact.
9. **Bake và GLB:** lưu .blend có rig điều khiển; bake kết quả vào xương deform/object transforms mà GLB hỗ trợ. GLB không mang toàn bộ hệ IK/constraint Blender sang engine. Đầu ra: GLB và manifest. Gate: export–reimport bảo toàn chuyển động [S5].
10. **QC offline:** xem rear/side/front, tốc độ thường và chậm; so sánh với sheet, dùng target cầu giả lập. Gate: không blocker; lưu kết quả và lỗi. Target giả lập chỉ kiểm tra contact có chủ ý, chưa chứng minh đánh cầu động.
11. **Runtime verification sau phê duyệt riêng:** kiểm tra skeleton, state transitions, tốc độ motor, contact window, bounded correction và replay. State graph PlayCanvas có cơ chế state/transition/layer, nhưng tài liệu công cụ không chứng minh rig này chạy đúng [S6].

### Root motion và in place

Root motion: clip mang chuyển động dịch cả nhân vật. In-place: clip bước tại chỗ, motor dịch nhân vật. Đề xuất thử in-place cho di chuyển liên tục và thử displacement profile được ghi từ clip cho lunge/recovery. Motor là nguồn vị trí gameplay duy nhất; nếu dùng root motion sau này, motor phải tiêu thụ displacement đó, không cộng thêm lần nữa. Đề xuất này còn OPEN, không khóa trong báo cáo.

Lưu bản có root trajectory khi nghiên cứu; không xóa bằng chứng di chuyển của mocap. Blender dùng Z-up, đặc tả game dùng Y-up; exporter chuyển hệ tọa độ, cần kiểm tra scale/hướng ở reimport và viewer trước khi xoay thủ công thêm.

### Aim assist và contact

Theo B5, gameplay xác nhận hit hợp lệ trong vùng giới hạn và animation được chỉnh nhỏ để bám impact. Phải định nghĩa miền contact clip hỗ trợ về độ cao, hướng, tầm với và trạng thái chân. Hướng ngắm/điểm rơi khác với hướng quay cả thân; không xoay cả model tùy ý khi chân đang trụ. Ngoài miền đó chọn variant, điều chỉnh chuẩn bị trong giới hạn hoặc đánh hụt. Không kéo tay vô hạn hoặc dịch cầu tới vợt.

Contact marker là dữ liệu thời gian của animation; không tự là quyết định tính điểm. Nếu clip đổi tốc độ hoặc bị trim, phải cập nhật mapping thời gian marker. Marker trong timeline Blender không được mặc định tự xuất thành gameplay event GLB; manifest là dữ liệu có truy vết riêng.

### Layer và replay

Overhead, lunge và recovery ưu tiên full-body trong thử nghiệm vì thân và chân phối hợp. Chỉ tách upper/lower-body sau khi đã chứng minh blend không phá tư thế. Runtime IK là bước xử lý riêng, không tự xuất cùng Blender IK.

Replay muốn bảo toàn contact cần lưu hoặc tái tạo đúng actor transform, clip/time/blend, các target hoặc kết quả correction, racket và shuttle cùng thời điểm. Chỉ ghi tên clip chưa bảo đảm tái hiện pose đã chỉnh. Chưa chốt schema hoặc ngân sách replay trong milestone này.

## 8 Hướng dẫn Blender dành cho người mới

Đây là hướng dẫn để thực hiện sau khi chủ dự án duyệt; báo cáo không thực hiện các thao tác sau.

**Thuật ngữ:** mesh là bề mặt người; armature/rig là bộ xương như khung bên trong con rối; skinning là mức da đi theo từng xương; keyframe là mốc pose; Action là một động tác; retarget giống chuyển động của người cao sang người thấp nên phải chỉnh tỷ lệ; IK giống đặt bàn chân vào một điểm rồi để đầu gối/hông tìm tư thế phù hợp; bake là ghi kết quả đã điều khiển thành keyframe có thể phát lại; GLB là gói asset để trình duyệt đọc, không thay thế file .blend nguồn.

1. Khi được phép, chọn một bản Blender ổn định và ghi đúng phiên bản. Chuẩn bị model đã rig có quyền sử dụng, video/reference sheet và vợt đơn giản. Chưa cần làm nhân vật đẹp hoàn chỉnh.
2. File > Save As, lưu file .blend mới. Giữ bản gốc riêng; tạo các phiên bản trước retarget, sau cleanup và trước export.
3. Làm quen: chuột giữa xoay góc nhìn; Shift và chuột giữa dịch; lăn chuột zoom. Numpad 1/3/7 xem trước/bên/trên, hoặc dùng gizmo khi máy không có numpad.
4. File > Import, chọn glTF 2.0 hoặc FBX theo file. BVH cần importer tương thích phiên bản; không giả định menu có sẵn trong mọi bản. Nếu không có importer, ghi blocker, không cài add-on ngẫu nhiên.
5. Scene Properties > Units: Metric. Kiểm tra kích thước model bằng Dimensions và vật chuẩn chiều cao. Đặt mặt phẳng sàn; biết đâu là gốc model và hướng nhìn trước. Không Apply Transforms bừa lên rig đã có animation.
6. Chọn armature > Pose Mode. Xoay thử vai, khuỷu, gối nhẹ rồi hoàn tác. Nếu da bị kéo/gãy, sửa rig trước; Pose Mode điều khiển tư thế, Edit Mode sửa cấu trúc xương.
7. Chuyển một editor sang Dope Sheet > Action Editor. Chọn Action, nhấn Space phát. Lưu bản sao action trước khi sửa, xác nhận không vô tình chỉnh action dùng chung. Tên menu/slot khác nhau giữa các phiên bản; hướng dẫn thao tác cuối sẽ bám bản được duyệt.
8. Thiết lập fps scene phù hợp timeline. Import source motion nếu chọn mocap. So sánh số giây playback với nguồn, không chỉ số frame. Không đổi fps để che lỗi timing.
9. Retarget theo bone mapping đã ghi: đồng nhất rest pose, hướng xương và tỷ lệ; chuyển từ root/spine tới chi. Với rig đã hỗ trợ, dùng công cụ tương thích; nếu không, cần một lần cấu hình mapping/constraints bởi người có kinh nghiệm. Chưa có thao tác một-click được bảo đảm cho rig chưa chọn.
10. Với dựng tay, tạo pose ready, load, rotate, contact, follow-through và recovery trong Pose Mode; lưu keyframe Location/Rotation vào các xương điều khiển phù hợp. Đây là blockout tư thế, chưa đủ để kết luận chuyển động mượt.
11. Mở Graph Editor để chỉnh đường cong theo thời gian. Sửa hông/chân trước, rồi thân/vai, cuối cùng khuỷu/cổ tay/vợt. Không làm mượt toàn bộ đến mức mất nhịp tiếp đất hoặc vung vợt.
12. Xác định frame chân trụ, thiết lập foot IK target bằng control rig; đặt pole target để gối không lật. Giữ phần bàn chân đang tiếp xúc ổn định, cho phép xoay gót/mũi chân nếu reference cho thấy. IK influence phải tăng/giảm qua pha đặt/nhấc chân.
13. Gắn vợt vào socket/xương tay phải. Chỉnh cán nằm đúng trong tay và mặt vợt đúng hướng. Kiểm tra bàn tay không trượt khỏi cán ở toàn clip.
14. Đặt một target cầu giả lập tại contact; xem từ rear và side. Chỉnh pose có giới hạn. Nếu target không thể với tới bằng pose tự nhiên, đổi variant/target và ghi lý do thay vì kéo dài tay.
15. Đặt marker và ghi contact time/plant intervals trong manifest. Với loop, so sánh pose và tốc độ ở hai đầu. Thử ghép ready → clear → recovery và ready → lunge → recovery trên timeline.
16. Lưu .blend. Bake Action trên bản export: chỉ xương deform/transforms cần dùng, đúng frame range, visual result. Giữ control rig nguồn; không xóa IK ở bản gốc.
17. File > Export > glTF 2.0, chọn GLB, skinning và animation, chọn chế độ Actions/NLA phù hợp phiên bản [S5]. Bảo đảm tên action và vợt có trong output; exporter không mặc định bảo toàn mọi constraint/marker.
18. Mở scene mới, import GLB lại. Kiểm tra scale, hướng, tên/số action, vật liệu, vợt, thời lượng, plant và contact. Nếu action mất, quay lại thiết lập export; không coi file tạo được là đã đạt.
19. Ghi playback rear/side và QC checklist; nêu lỗi còn lại. Engine test chỉ thực hiện khi được phê duyệt riêng.

Người mới nên học theo file rig cụ thể. Hướng dẫn retarget/IK chi tiết đến từng click chỉ có thể hoàn thiện sau khi đã chọn model, Blender và công cụ tương thích; một chuỗi click chung cho mọi rig sẽ dễ sai.

## 9 Công cụ và chi phí

| Ưu tiên | Công cụ | Dùng cho | Giới hạn cần biết |
|---|---|---|---|
| Miễn phí trước | Blender | Rig, keyframe, cleanup, IK, bake, GLB | Cần học thao tác; chọn bản ổn định; không tự sinh footwork đúng [S1] |
| Miễn phí trước | Kinovea | Frame, slow playback, annotation và so sánh video | Phân tích 2D, không tự thành skeleton 3D [S2] |
| Miễn phí trước | Mixamo | Nhân vật/idle/locomotion nền để thử rig | Cần Adobe ID; không coi thư viện generic là bộ cầu lông đúng [S7] |
| Miễn phí có điều kiện | FreeMoCap | Quay và xử lý markerless nhiều camera | Cần setup/đồng bộ/hiệu chuẩn; chưa chọn làm nhánh chính [S4] |
| Thử miễn phí có giới hạn | DeepMotion Animate 3D | Một clip video mocap nếu được phép upload | FAQ hiện nêu Freemium 60 giây/tháng, cá nhân phi thương mại; điều khoản gói quyết định quyền dùng output [S8] |
| Trả phí nếu cần | DeepMotion gói phù hợp | Quyền/chức năng/hạn mức đáp ứng nhu cầu | Chỉ xem xét sau thử so sánh; không hứa mua gói sẽ sửa được video kém [S8] |
| Trả phí nếu cần | Dịch vụ animator hoặc buổi capture chuyên dụng | Tư thế vợt/footwork khó, nguồn dữ liệu kiểm soát | Cần mẫu test và thỏa thuận giao .blend, GLB, quyền sử dụng và lần sửa; chưa liên hệ/mua |

Adobe FAQ xác nhận Mixamo miễn phí với Adobe ID, không cần Creative Cloud subscription và có thể dùng nhân vật/animation trong game thương mại [S7]. Cần lưu điều khoản áp dụng cho asset đã lấy; không suy rộng sang model hoặc footage từ nơi khác.

DeepMotion có free credits không có nghĩa output mặc nhiên dùng được trong game thương mại. FAQ nói quyền theo plan; không mặc định nâng cấp sau này sẽ hợp thức hóa mọi output cũ. Chưa có căn cứ định giá gói cụ thể từ nội dung đã đọc, nên báo cáo không báo giá USD hoặc ngân sách mua.

Bộ khởi đầu đề xuất: Kinovea và Blender, một rig hợp lệ, thư viện nếu cần. Video mocap là phép thử sau source gate; không phụ thuộc bắt buộc cho M1. Công cụ trả phí chỉ được đề nghị khi có blocker cụ thể và đánh giá lợi ích so với tiếp tục miễn phí.

## 10 Tiêu chí nghiệm thu và bằng chứng

G1–G7 của E8 được giữ nguyên nguyên tắc. Các kiểm tra sau mở rộng cách thu bằng chứng; chưa thay đổi DR12 hoặc tuyên bố đã pass.

| Gate | Điều kiện để qua | Deliverable bằng chứng | Trạng thái v0.1 |
|---|---|---|---|
| G1 Reference | Ít nhất một clip có sáu mốc/nhãn tin cậy, nguồn và giới hạn; dùng N/A đúng mục tiêu | Sheet, frame/timecode, rubric | Chưa kiểm chứng |
| G2 Rig | Nam tay phải, tỷ lệ/scale xác định, mapping và skinning không blocker | Rig spec, pose test, .blend nguồn | Chưa thực hiện |
| G3 Transfer | Ít nhất một action chạy đầy đủ trên rig đích, thời lượng/hướng đúng | .blend, playback, bone map | Chưa thực hiện |
| G4 Contact | Vợt/target gặp nhau có chủ ý, không sửa chi phi tự nhiên; kiểm tra rear/side | Contact sheet, frame trước/sau, offset đo | Chưa thực hiện |
| G5 Foot plant | Chân trụ không trượt rõ ở tốc độ thường; không khóa cả chân khi cần pivot | Video và drift/penetration record | Chưa thực hiện |
| G6 GLB | Reimport giữ scale, skinning, tên/số clip, thời lượng và vợt | GLB, QC so với .blend | Chưa thực hiện |
| G7 Documentation | Tái lập được nguồn, phiên bản, export settings, quyền và lỗi | Manifest, checklist, issue log | Chưa thực hiện |

### Cách đo và quyết định

Chuẩn hóa scale trước. Đo foot drift trong world space ở đúng điểm heel/toe/sole đang trụ so với đầu interval; không đo cả đường đi của nhân vật. Đo xuyên sàn ở các điểm chân; loại trừ nhấc chân hợp lệ. Đo khoảng cách điểm impact mục tiêu tới vùng mặt dây vợt, không chỉ tới tâm bàn tay. Đo sai lệch thời gian bằng giây/ms với đúng mapping nguồn–clip–playback; contact nguồn có uncertainty interval thì giữ interval.

Đo pose/chuyển động .blend so với GLB sau reimport ở cùng thời điểm. Phát loop nhiều vòng, kiểm tra chuyển ready–move–lunge–recovery và ready–overhead–recovery. Kiểm tra biến dạng vai/cổ tay, xuyên người/cán vợt, lật gối, snap root và kết thúc mất thăng bằng từ rear, side, front; không dùng một góc camera che lỗi làm tiêu chuẩn.

Không khóa ngưỡng cm/ms trước khi có rig theo DR12. Tại M1, thu baseline drift, contact error, export error và đánh giá trực quan; đề xuất ngưỡng cùng ảnh/video chứng minh chủ dự án duyệt. Giới hạn sai số nguồn không phải giấy phép để chấp nhận sai số animation tùy ý. Bất kỳ lệch rõ, gãy chi, contact ngoài tầm hoặc animation mất khi xuất là FAIL dù số trung bình đẹp.

Nếu cần ngưỡng số để kiểm thử ban đầu, lập một QC Draft riêng sau scale test; chưa dùng con số tùy chọn trong v0.1 làm tiêu chuẩn chính thức. Chỉ thay DR12 khi chủ dự án phê duyệt.

Pass G1–G7 với một clip nghĩa là nhánh pipeline tối thiểu hoạt động, không chứng minh motion giống tuyệt đối VĐV, tất cả kỹ thuật đạt, hiệu năng web đạt hoặc contact cầu động đúng. Bổ sung lunge/recovery trước khi kết luận nhánh locomotion khả thi. Browser performance và runtime correction nằm ở milestone kỹ thuật sau, cần dữ liệu trên máy thật.

## 11 Roadmap theo milestone

Giữ hệ M0–M6 của v1.1. AF là checkpoint con thuộc nghiên cứu/Animation Feasibility, không phải thay milestone dự án. Không gắn lịch 9 ngày hoặc hứa ngày hoàn thành khi chưa có data.

| Checkpoint | Deliverable | Acceptance criteria | Rủi ro và cách xử lý |
|---|---|---|---|
| AF0 hiện tại | Report v0.1, conflict log, template và đề xuất decision | Chủ dự án hiểu phạm vi, hạn chế và duyệt bước tiếp | Duyệt kế hoạch bị hiểu là duyệt code; ghi rõ phạm vi |
| AF1 Source review | Ba mẫu ứng viên, source register, rubric | Nhìn được frames, xác định mục tiêu/tay thuận/metadata/quyền hoặc ghi UNKNOWN; ít nhất một nguồn đủ reference | V01/V02 không truy cập được; dùng MP4/frame hoặc quay mới |
| AF2 Reference analysis | Sheet ready/split, lunge/recovery và clear; sơ đồ pha và plant | Quan sát có truy vết, sáu mốc hoặc N/A hợp lệ; contact uncertainty được ghi | Khuất/mờ; bổ sung góc/frame, không đoán |
| AF3 Rig và transfer plan | Rig/model shortlist, mapping, source method, QC draft | Một phương án được duyệt với quyền phù hợp và hướng/scale rõ | Rig xấu hoặc add-on không tương thích; pose test trước motion |
| AF4 thuộc M1 | Clear đã retarget/dựng, vợt, target giả lập, .blend và GLB | G2/G3/G4/G6/G7 pass trên clip clear; không blocker | AI không giải được cổ tay/vợt; dùng chỉnh tay, chưa sản xuất hàng loạt |
| AF5 thuộc M1 | Split-step và lunge/recovery, blend trials, QC review | G5 pass trên plant; chuyển pha ổn định; xác nhận điều kiện/tồn đọng và QC thresholds để duyệt | In-place và motor lệch, recovery trượt; đổi policy thử nghiệm trong phạm vi duyệt |
| AF6 cổng M1 | Báo cáo v0.2 kết quả, go/no-go từng nhánh và backlog | Evidence G1–G7, lỗi nghiêm trọng đã xử lý; chủ dự án duyệt M2 riêng | Nhầm một clip pass là toàn hệ pass; phân kết luận theo kỹ thuật |

AF1–AF2 vẫn là nghiên cứu; AF3 là lựa chọn/thiết kế. AF4–AF5 tạo asset thực nghiệm nên phải có phê duyệt bước đó. AF0 không tự mở AF4.

| Milestone dự án về sau | Deliverable | Acceptance criteria trọng tâm | Rủi ro |
|---|---|---|---|
| M2 First Playable | Một lát cắt sân–motor–camera–cầu–animation | Rally cơ bản có contact đúng, không dịch chuyển cầu để che lỗi; benchmark skeleton/GLB trước khóa engine | Motor/animation bất đồng bộ, engine không đáp ứng |
| M3 Match MVP | Quick Match AI và Training, 11/15/21 | Chơi hết trận; AI cùng giới hạn; rulesets được kiểm chứng; P0 coverage đủ | Net/drive scope chưa duyệt, AI dùng pose không khả thi |
| M4 Realistic Polish | Animation/PBR/SFX đã nâng cấp | Footwork/contact đạt QC; hình ảnh và frame time có bằng chứng | Đẹp hơn nhưng nặng hoặc sai chuyển động |
| M5 P1 | Replay, presets, stats/history | Replay không thay kết quả và bảo toàn pose/contact; settings có tác động | Không ghi đủ correction state; vượt memory budget |
| M6 Production | Bản đã QA và release checklist | Chỉ triển khai khi được phép; asset/luật/hiệu năng và trình duyệt qua gate | Lỗi asset, giấy phép hoặc hiệu năng trên máy khác |

Các hàng M2–M6 chỉ cho thấy phụ thuộc dài hạn, không là phép triển khai trong nhiệm vụ này. Thời gian/nguồn lực sẽ ước tính sau khi có source và đo thời gian cleanup một mẫu; chất lượng là điều kiện tiến milestone.

## 12 Decision register đề nghị chủ dự án duyệt

LOCKED giữ nguyên toàn bộ quyết định handoff. Những lựa chọn sau là OPEN; mã AF dùng trong báo cáo mới, không ghi đè mã D/DR của baseline.

| Mã | Quyết định còn mở | Khuyến nghị | Khi cần duyệt |
|---|---|---|---|
| AF D01 | Phạm vi bước tiếp | Chỉ AF1–AF2, nghiên cứu clip và reference sheets | Ngay sau v0.1 |
| AF D02 | Nguồn đầu tiên | Clip clear, split-step, lunge/recovery nhìn rõ; V01/V02 chỉ chọn sau xem | Khi cung cấp dữ liệu |
| AF D03 | Rubric và sáu mốc | Giữ E4; chuẩn hóa 6 mốc, CONTACT N/A với footwork | Trước AF2 |
| AF D04 | Animation scope | Net cơ bản P0, drive P1; không áp trần 8–12 action | Trước khóa backlog sản xuất |
| AF D05 | Rig/model và Blender | Một rig nam tay phải hợp lệ, một bản ổn định | Trước AF4 |
| AF D06 | Nhánh mocap và bên thứ ba | Reference/dựng tay trước; upload chỉ khi footage/quyền và phương án được duyệt | Sau AF2 |
| AF D07 | Root motion và IK policy | Thử in-place locomotion và displacement lunge; motor nguồn vị trí duy nhất | Trước thử motion/runtime |
| AF D08 | QC cuối | Đo baseline trên rig, rồi trình ngưỡng cm/ms có bằng chứng | Review AF4–AF5 |
| AF D09 | Engine và budget | Giữ PlayCanvas/TS/Vite ứng viên; benchmark trước khóa | Trước M2, phê duyệt riêng |
| AF D10 | Replay và luật | Giữ OPEN về độ dài/pose data và ruleset/default chi tiết | Milestone tương ứng |

Đề nghị duyệt hiện tại: kế hoạch AF1–AF2 và template; chưa yêu cầu duyệt rig, paid tools, code hoặc deploy. Muốn sửa GDD/TDD sẽ trình danh sách chỉnh cụ thể C01–C06 trước.

## 13 Nguồn công cụ đã tham khảo

Truy cập/nghiên cứu ngày 13/10/2026. Các giới hạn gói và giao diện cần kiểm tra lại trước sử dụng. Đây là tài liệu công cụ, không phải chứng cứ chất lượng animation Shuttle Arena 3D.

- S1 Blender About https://www.blender.org/about/ — xác nhận phần mềm miễn phí, nguồn mở và dùng cho mục đích thương mại/giáo dục.
- S2 Kinovea https://www.kinovea.org/ — annotation, slow playback, so sánh, đo video; miễn phí/nguồn mở.
- S3 DeepMotion Single Person Capture Guide https://www.deepmotion.com/article/single-person-capture-guidelines-for-animate-3d — camera, toàn thân, che khuất và chất lượng quay. Một số đoạn mô tả tính năng có thể cũ; không suy rộng sang mọi chế độ hiện hành.
- S4 FreeMoCap Docs https://docs.freemocap.org/ — markerless, single/multi-camera, calibration và Blender add-on.
- S5 Blender glTF export manual https://docs.blender.org/manual/en/5.3/addons/scene_gltf2.html và https://docs.blender.org/manual/vi/5.0/addons/import_export/scene_gltf2.html — kết quả tra cứu chính thức về animation modes và bake. Trang đầy đủ không mở được trong phiên này; thiết lập export từng click phải xác nhận theo bản Blender chọn sau, không chọn bản beta chỉ vì URL tài liệu.
- S6 PlayCanvas Animstategraph Assets https://developer.playcanvas.com/user-manual/animation/anim-state-graph-assets/ — state, transitions và layers; chưa thử tích hợp.
- S7 Adobe Mixamo FAQ https://helpx.adobe.com/creative-cloud/faq/mixamo-faq.html — miễn phí với Adobe ID, sử dụng nhân vật và animation trong game.
- S8 DeepMotion Animate 3D pricing FAQ https://www.deepmotion.com/pricing-animate3d — Freemium phi thương mại và quyền theo plan. Giá gói cụ thể chưa xác nhận, không báo giá.
- V01 https://youtu.be/zYqgJo1L5uM và V02 https://youtu.be/VD8ZfEW94mk — nguồn do chủ dự án cung cấp; chưa xem được frames, chưa phân tích motion.

**Điểm dừng:** chờ chủ dự án duyệt kế hoạch và cung cấp clip/frame trước khi tiến AF1–AF2. Chưa có animation nào được nghiệm thu.
