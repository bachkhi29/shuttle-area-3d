# Shuttle Arena 3D — Handoff sang Codex

Ngày 14/10/2026. Dành cho phiên Codex mới. Chủ dự án là người mới với Blender/3D, muốn **vibe coding**: agent tự làm, tự chạy và giao bản chơi thử, giải thích ngắn gọn bằng tiếng Việt.

## Trạng thái hiện tại

- Game cầu lông 3D chạy trình duyệt. Quyết định khóa: High-Fidelity Realistic 3D là mục tiêu; Arcade + Aim Assist; camera góc sau sân; avatar đầu tiên nam thuận tay phải; Quick Match có AI nhiều mức và Training; lựa chọn 11/15/21 điểm với luật phù hợp; animation hybrid từ thư viện + video reference/mocap có điều kiện + Blender; Replay, Graphics Presets, Statistics, History; phát triển theo milestone chất lượng, không ép 9 ngày. PlayCanvas/TypeScript/Vite/Blender là **ứng viên**, chưa chốt stack.
- GDD/TDD v1.1: `Shuttle_Arena_3D_GDD_TDD_v1.1_Animation_Feasibility(2).docx` là đặc tả chính. Cần gắn trực tiếp file này trong phiên mới; nó **không nằm trong gói chuyển giao** vì không có bản local ở đây.
- Animation Feasibility Report v0.1 có đối chiếu GDD và quyết định; C01–C06 là các điểm cần xử lý trước khi sửa GDD. Không tự đổi quyết định khóa.
- Motion Reference Sheets v0.1/v0.2 và AF2 Decision v0.3: đã xem bốn clip MP4 người dùng gửi. Video trận dùng tham khảo footwork; hai clip split-step cho tư thế và bối cảnh rally; clip overhead có jump overhead, không xem là clear. BWF Coach Manual Level 1 bổ sung chuẩn cho lunge/recovery và forehand clear. Không tự bịa frame contact hoặc biến footage 2D thành 3D chính xác.
- Chủ dự án đã duyệt **bắt đầu AF3**, rồi làm rõ muốn **vibe coding, không cần tự cài Blender**. Vì vậy lệnh “không viết code” trong handoff nghiên cứu ban đầu đã được thay bằng yêu cầu code mẫu thử. Các hạn chế **không deploy, không mua/đăng ký trả phí, không tự đổi quyết định chốt, không tuyên bố chất lượng animation khi chưa kiểm chứng** vẫn còn hiệu lực. Chưa có yêu cầu tạo repository.
- Đã tạo `Shuttle_Arena_3D_Footwork_Prototype_v0.1.html`: một file HTML độc lập/offline, sân và nhân vật dạng khớp từ tọa độ 3D chiếu phối cảnh, action ready → split → travel → lunge → recover; góc sau/bên, tua/tốc độ. Đây là **greybox nghiên cứu chuyển động**, chưa phải PlayCanvas, GLB hay high-fidelity asset. Cú pháp JavaScript qua `node --check`; chưa kiểm tra visual trong trình duyệt do môi trường thiếu browser executable.
- `Shuttle_Arena_3D_AF3_Pose_Board_and_QC_v0.1.md` ghi 6 pose lunge, 6 pose clear và gate kiểm tra. Workspace vừa qua không có Blender hoặc rig. Chưa có `.blend`, `.glb`, game loop, AI hay match.

## Việc cần làm đầu tiên trong Codex

1. Đọc GDD/TDD v1.1, báo cáo feasibility, reference sheets, AF2/AF3 và HTML mẫu thử. Đánh dấu điểm nào là đặc tả, điểm nào chỉ là giả thuyết chuyển động. Không tự sửa GDD nếu thấy xung đột; trình sai khác.
2. Mở HTML mẫu thử trong trình duyệt, kiểm tra hình thực tế và hai góc camera; sửa lỗi runtime/chiếu hình nếu có. Giao ảnh/video hoặc bản chạy cho chủ dự án. Không khẳng định chân trụ/contact đã đạt chỉ vì hoạt họa nhìn ổn.
3. Thiết kế **vertical slice nhỏ có thể chơi** trên browser: sân, một avatar điều khiển được, cầu, lưới, di chuyển, một cú đánh, đối thủ AI đơn giản, điểm số tối thiểu. Định hướng PlayCanvas/TypeScript/Vite chỉ chốt sau khi thử khả năng phù hợp. Ưu tiên vòng tương tác chạy được và footwork hợp lý; giữ phạm vi nhỏ. Nếu cần cài dependencies, agent tự làm trong môi trường phát triển; người dùng chỉ xem bản chạy.
4. Tách animation thành mốc chân chạm sân, contact, recovery và blend. Dùng BWF + footage đã gắn nhãn để thiết kế, sau đó QC từ góc sau và bên. Có thể đề xuất dùng rig/asset miễn phí có quyền hợp lệ; chưa upload clip sang mocap bên thứ ba hoặc mua dịch vụ.
5. Mỗi milestone giao bản xem được, acceptance criteria, rủi ro và trạng thái PASS/FAIL/NOT TESTED. Chỉ xin chủ dự án duyệt các quyết định lớn: engine chính thức, asset/license, công cụ trả phí, thay đổi GDD, deploy hoặc mở rộng phạm vi.

## Quy tắc trao đổi

- Xưng tôi–ông, hướng dẫn tiếng Việt, giải thích thuật ngữ đơn giản. Chủ dự án không biết Blender và không cần tự thực hiện thao tác kỹ thuật.
- Vibe coding: agent viết, chạy, kiểm tra; người dùng phản hồi cảm giác chơi và hình ảnh. Không bắt người dùng cài phần mềm chỉ để xem bản đầu.
- Tách rõ **quan sát video**, **nguồn huấn luyện**, **thiết kế đề xuất**, **bằng chứng chạy thực tế**. Tránh phát biểu “chuẩn xác” nếu chưa có QC.
- Không tạo repo hoặc deploy chỉ để có bản thử đầu tiên. Nếu về sau cần lưu trữ dài hạn, trình lựa chọn cho chủ dự án.

## Prompt mở phiên Codex (chép nguyên khối)

> Tiếp tục dự án Shuttle Arena 3D từ gói handoff đính kèm. Tôi muốn vibe coding: ông trực tiếp viết, chạy, kiểm tra bản thử browser; tôi chỉ xem, chơi và phản hồi, chưa biết Blender. Đọc `Shuttle_Arena_3D_Codex_Handoff.md`, GDD/TDD v1.1, báo cáo feasibility và các motion sheet trước. Trước tiên kiểm tra/sửa file HTML mẫu thử và cho tôi một bản xem được; sau đó đề xuất vertical slice cầu lông 3D chơi được theo milestone. Giữ các quyết định khóa, không mua dịch vụ, không deploy hay tạo repository khi tôi chưa yêu cầu. Phân biệt chuyển động đã quan sát với thiết kế suy ra, không tự nhận animation đạt chuẩn khi chưa kiểm chứng. Báo ngắn gọn kết quả và rủi ro bằng tiếng Việt.

## Các file nên đính kèm

1. GDD/TDD v1.1 từ Project: `Shuttle_Arena_3D_GDD_TDD_v1.1_Animation_Feasibility(2).docx`.
2. Toàn bộ gói này gồm handoff, `Shuttle_Arena_3D_Animation_Feasibility_Report_v0.1.md`, ba bản motion sheet/AF2, pose board AF3 và HTML mẫu thử.
3. Bốn video nguồn **khi Codex cần rà lại khung hình**: `Axelsen_vs_LeeZiiJia.mp4`, hai video split-step và video overhead. Vì clip trận lớn, không cần đính kèm cả bốn ngay nếu phiên mới đã nhận được sheet và chưa phân tích lại footage.

Lưu ý: hội thoại hiện tại và thư mục tạm của Work không tự biến thành thư mục dự án của phiên Codex mới. Hãy đính kèm gói và GDD/TDD, hoặc đặt các file vào folder mà Codex mới được phép đọc.
