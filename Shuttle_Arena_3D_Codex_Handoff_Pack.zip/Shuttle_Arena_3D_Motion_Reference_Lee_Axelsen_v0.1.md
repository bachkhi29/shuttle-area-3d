# Shuttle Arena 3D — Motion Reference Sheet v0.1

Ngày phân tích: 14/10/2026. Trạng thái: **quan sát sơ bộ từ clip đã gửi; chưa duyệt làm dữ liệu mocap hoặc animation**. Phạm vi: AF1–AF2 của Animation Feasibility Report v0.1. Tất cả mốc dưới đây là **thời gian của file MP4 đính kèm**, không phải thời gian của video YouTube dài 11:33. Mốc làm tròn theo các khung mẫu cách nhau 0,2–0,5 giây; không phải frame contact đã xác nhận.

## Nguồn và giới hạn

| Trường | Ghi nhận |
|---|---|
| File | `Axelsen_vs_LeeZiiJia.mp4`, do chủ dự án gửi; 114,8 giây; 1920×1080; video H.264, 30 fps danh nghĩa của **file này**; âm thanh AAC. Chưa biết fps gốc trước khi cắt/xuất. |
| Nội dung nhìn thấy | Nhiều pha cầu đơn, hai người chơi áo trắng và áo đỏ/đen; góc truyền hình chủ yếu nhìn từ sau sân người áo trắng, có các đoạn cắt sang góc thấp. |
| Danh tính và tay thuận | Không xác nhận danh tính hoặc tay thuận bằng tên file; dùng “người áo trắng” và “người áo đỏ/đen” trong sheet. |
| Mục đích | Tham khảo tư thế, vùng sân và thứ tự động tác. Nguồn truyền hình cắt cảnh và phối cảnh xa nên chưa dùng để trích skeleton 3D chính xác. |
| Quyền sử dụng | Chủ dự án đã gửi file để phân tích trong phiên làm việc; quyền tái sử dụng footage và quyền đưa motion/phái sinh vào game **chưa xác minh**. Không upload sang dịch vụ mocap. |
| Nhãn | **Quan sát:** hình thể/đường đi nhìn được. **Suy luận:** tên kỹ thuật, lực, ý định hoặc tiếp xúc chưa thấy chắc. **Chưa rõ:** không đủ dữ liệu. |

## REF-01: ready và phòng thủ ngang — ứng viên P0

**Đoạn:** 00:43,8–00:45,0; nhân vật áo trắng ở nửa sân gần. **Giá trị:** tư thế chờ, mở chân để đón đường cầu ngang và thu về. Chưa xác nhận được một split-step hoàn chỉnh vì không nhìn rõ cả hai bàn chân rời sàn rồi tiếp đất.

| Mốc file | Quan sát trực tiếp | Suy luận/giới hạn |
|---|---|---|
| 00:43,8–00:44,0 | Hai chân mở rộng, gối gập; thân hơi thấp và hướng vào đối thủ; tay cầm vợt đưa phía trước. | Mẫu tư thế phòng thủ tương đối tốt; không suy ra trọng lượng chia đều hai chân. |
| 00:44,0–00:44,2 | Chân mở rộng thêm theo hướng ngang trên màn hình; thân thấp hơn; cánh tay và vợt hướng ra bên trái màn hình. | Có thể là bước đón cầu ngang; loại cú đánh, mặt vợt lúc chạm và vị trí cầu tại contact chưa rõ. |
| 00:44,4–00:44,8 | Người áo trắng kéo chân lại, thân nâng lên và hướng gần vị trí giữa sân hơn. | Có thể làm reference cho recovery ngắn; chưa đo được quãng đường hoặc nhịp chân thực ở tốc độ cao. |

**Ứng dụng thiết kế:** ready có gối chùng và vợt ở trước thân; khi phòng thủ ngang, thay đổi bề rộng chân và độ cao hông, sau đó thu chân về. Không dùng một pose hai chân dạng rộng cố định cho toàn bộ rally.

## REF-02: cú cứu cầu thấp và mất thăng bằng — reference đặc biệt

**Đoạn:** 00:30,8–00:33,4; nhân vật áo trắng. Đây là ví dụ chân thực về **giới hạn hồi vị trong pha cứu cầu**, không phải mẫu forward lunge chuẩn cần sao chép cho P0.

| Mốc file | Quan sát trực tiếp | Suy luận/giới hạn |
|---|---|---|
| 00:30,8–00:31,0 | Người áo trắng lao ngang về phía bên phải màn hình, hai chân cách xa, thân hạ thấp. | Có thể là cố vươn tới cầu thấp; không xác nhận đúng loại cú đánh. |
| 00:31,2–00:31,4 | Bàn tay/thân xuống thấp gần mặt sân, gối và hông tiếp tục hạ; tư thế mất thăng bằng. | Không thể gán một chân trụ ổn định xuyên suốt. |
| 00:32,6–00:33,4 | Một pha cứu cầu thấp khác trong cùng chuỗi, thân gần sàn rồi chống dậy. | Clip này có thể là reference cho *emergency save* về sau; không thay thế lunge và recovery chuẩn. |

**Ứng dụng thiết kế:** tránh giả định mọi cú với cầu thấp đều phải kết thúc bằng hồi vị ngay tức thì. Đưa vào danh mục Future hoặc biến thể cứu cầu muộn sau khi P0 ổn định.

## REF-03: chuẩn bị đánh trên cao — chưa đủ để gắn nhãn clear

**Đoạn:** 01:30,2–01:31,2 và diễn tiến tiếp theo tới 01:32,4; người áo trắng. Có pha tay/vợt nâng lên và thân ngả khi xử lý cầu cao, nhưng người chơi sau đó vươn rất xa rồi mất thăng bằng.

| Mốc file | Quan sát trực tiếp | Suy luận/giới hạn |
|---|---|---|
| 01:30,2–01:30,6 | Chân người áo trắng mở ở vùng giữa sân gần; tay không vợt và vợt thay đổi vị trí khi theo dõi pha cầu. | Chưa đủ để xác nhận bước xoay người chuẩn cho clear. |
| 01:30,8–01:31,0 | Vợt/tay nâng cao, thân quay và ngả; tới 01:31,2 người chơi đổ sang bên sau động tác. | **Chưa xác nhận** cú đó là forehand overhead clear; điểm chạm cụ thể và quỹ đạo bay sau impact không đủ rõ. |
| 01:31,8–01:32,4 | Người áo trắng có pha vươn cao tiếp theo rồi ngả mạnh, chân sau rời vị trí cân bằng. | Không lấy làm chuẩn cho overhead clear đứng cân bằng. |

**Trạng thái AF2:** đủ để ghi nhận ứng viên chuyển động trên cao; **chưa có sheet forehand overhead clear đạt chuẩn**. Cần đoạn khác có trọn thân, vợt và cầu, nhìn được từ chuẩn bị đến hồi vị, tốt nhất góc bên hông hoặc chéo sau sân.

## Đánh giá nguồn cho ba mục tiêu đầu

| Mục tiêu | Trạng thái hiện tại | Lý do |
|---|---|---|
| Ready stance | Có reference sơ bộ | Thân, khoảng chân và vị trí vợt nhìn thấy ở các đoạn như 00:43,8–00:44,0. |
| Split-step | Chưa xác nhận | Chưa chốt được khung cả hai chân rời sàn/tiếp đất từ những đoạn đã chọn. |
| Forward lunge + recovery | Chưa đủ mẫu chuẩn | Đoạn 00:30,8–00:33,4 là lao cứu cầu ngang, mất thăng bằng; không thích hợp làm mẫu lunge tiến lưới. |
| Forehand overhead clear | Chưa xác nhận | Góc quay xa và chuỗi hành động không đủ để phân biệt clear với động tác trên cao khác. |

**Quyết định nguồn tạm thời:** `REFERENCE ONLY` cho thế sẵn sàng, phòng thủ ngang và rescue. `MOCAP CANDIDATE = chưa đánh giá`: cần kiểm tra quyền sử dụng và chọn clip toàn thân liên tục có góc quay phù hợp; việc file xuất 30 fps không chứng minh nguồn gốc footage 30 hoặc 50 fps. Không gán điểm rubric 0–12 khi quyền và điều kiện thu thập chưa rõ.

## Việc tiếp theo trong AF1–AF2

1. Tiếp tục tuyển ba đoạn rõ ràng: split-step hoàn chỉnh, lunge tiến lưới có hồi vị, forehand overhead clear có cầu và vợt nhìn thấy quanh contact. Có thể dùng chính file này nếu đoạn đủ tốt được xác nhận sau xem chi tiết, hoặc dùng clip khác.
2. Với mỗi đoạn, đánh dấu sáu mốc theo template của báo cáo v0.1: ready, load/split, move/rotate, contact hoặc N/A, follow-through, recovery. Ghi timecode và uncertainty khi chỉ biết một khoảng.
3. Chỉ sau khi sheet đủ bằng chứng mới cân nhắc test rig/Blender; chủ dự án không cần thao tác phần mềm 3D ở giai đoạn này.

**Không có animation, skeleton, GLB hay chất lượng chuyển động game nào được nghiệm thu từ sheet này.**
