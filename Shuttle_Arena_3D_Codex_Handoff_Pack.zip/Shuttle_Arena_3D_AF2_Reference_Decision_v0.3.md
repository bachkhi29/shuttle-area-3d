# Shuttle Arena 3D — AF2: quyết định nguồn chuyển động v0.3

Ngày 14/10/2026. Tài liệu nghiên cứu/thiết kế để chủ dự án xem xét, **chưa phải animation 3D hoặc kết quả nghiệm thu**. Kế thừa Motion Reference Sheets v0.1 và v0.2. Không sửa các quyết định sản phẩm đã chốt.

## 1. Rà lại trận Axelsen–Lee Zii Jia

File nhận được dài 114,8 giây, 30 fps danh nghĩa, là clip cắt ghép nhiều rally. Mốc sau tính theo file, ước lượng từ các chuỗi khung hình đã xem; không phải điểm chạm được đo chính xác.

| Khoảng xem | Quan sát trực tiếp | Kết luận cho mẫu P0 |
|---|---|---|
| 00:08–00:10 | Người áo trắng đi từ giữa sân gần lên phía trước, mở rộng chân và với vợt tới cầu, sau đó thu chân để tiếp tục pha. | Có ích để kiểm tra dáng tiến lưới trong trận, nhưng không nhìn rõ chân trụ và điểm chạm. Giữ nhãn *ứng viên bổ trợ*, chưa làm mẫu lunge chuẩn. |
| 00:24–00:28 | Hai người liên tục đổi hướng; người áo đỏ/đen ở sân xa có các pha chùng gối/vươn tới vùng trước. | Người ở xa nhỏ; thiếu hình học chân và mặt vợt. Dùng nhịp rally, không dùng để trích 3D. |
| 01:08–01:13 | Người áo trắng di chuyển nhanh và hạ rất thấp, có pha phải chống người; sau đó tiếp tục di chuyển. | Mẫu cứu cầu áp lực cao, không phải recovery chuẩn cho P0. |
| 01:46–01:54 | Liên tiếp vươn ngang thấp và ngã/đổ người, xen đoạn cắt camera. | Dành cho biến thể cứu cầu về sau. Không dùng làm mẫu mặc định. |

Trong file có nhiều tư thế đánh trên cao, nhưng **không đủ bằng chứng thị giác để gắn nhãn một chuỗi cụ thể là forehand overhead clear**: một cú clear cần xác nhận đường bay từ cuối sân mình sang cuối sân đối phương, còn ảnh trận đấu xa và cầu thường nhòe/ra khỏi khung. Không tự đổi nhãn overhead sang clear.

## 2. Chuẩn kỹ thuật bổ sung từ BWF

Nguồn: BWF *Badminton Coach Education — Coaches’ Manual Level 1*, Module 6 (movement patterns), Module 7 (Forehand Clear). BWF mô tả di chuyển đến góc lưới thuận tay bằng các biến thể như split-step → chasse/chạy → lunge → chasse/bước lùi; chân trước và gối hướng cùng phía tới vùng chạm cầu, hồi vị phải giữ tư thế. Đây là **mẫu huấn luyện tham khảo**, không khẳng định mọi rally đều theo một mẫu duy nhất. genui{"citation":{"refs":["turn12view0","turn12view2"]}}

BWF mô tả forehand clear với tư thế xoay ngang, tay không vợt giơ lên, đẩy từ chân sau và xoay hông/vai, tiếp xúc phía trên hoặc hơi trước vai cầm vợt, rồi chân sau vượt chân trước khi hoàn tất chuyển động. Clear đưa cầu từ cuối sân của mình tới cuối sân đối phương; nó có biến thể tấn công và phòng thủ. Đây là **đặc tả chuyển động nguồn**, chưa phải kết quả quan sát clear trong clip người dùng. genui{"citation":{"ref":"turn12view1"}}

## 3. Đề xuất hai motion card để thử trên rig sau này

### P0-LUNGE-FH-01 — tiến lưới thuận tay và hồi vị, nhân vật nam tay phải

1. **READY:** thân và vợt hướng về đối thủ, hai gối mềm; xác định vị trí ban đầu theo sân 3D.
2. **SPLIT/REACT:** chân tiếp đất, thân hạ và chọn hướng vào góc trước thuận tay. Khóa thứ tự các sự kiện sau khi chọn footage có chân rõ; không áp thời gian tuyệt đối từ tutorial.
3. **TRAVEL:** bước dẫn/chasse hoặc bước chạy tùy khoảng cách. Đặt hông, vai và vợt theo đường cầu; không bắt nhân vật trượt ngang với chân trụ đứng yên.
4. **LUNGE/CONTACT:** chân cầm vợt (phải) là **phương án chuẩn đề xuất cho biến thể này theo giáo trình**; tiếp đất ở phía trước, gối và bàn chân cùng hướng, vợt vươn ra trước. Đây là quy tắc cho action cụ thể, không áp cho mọi tình huống cứu cầu.
5. **PUSH/RECOVERY:** chân trước đẩy ngược, thân quay về vùng có thể đón cầu tiếp; một bước lùi hoặc chasse, rồi nối vào ready. Không phát lunge ngược như một đoạn video đảo chiều.

**Điểm cần đo trên rig:** chân trước không trượt khi đang trụ; đầu gối không xoắn lệch mũi chân; vợt có thể gặp cầu ở vùng hợp lý; hồi vị không dịch tức thời đến giữa sân. **Rủi ro:** clip trận không nhìn rõ contact và chân; phải kiểm chứng chuyển động thử từ ít nhất hai góc camera trong cảnh 3D.

### P0-CLEAR-FH-01 — forehand overhead clear, nhân vật nam tay phải

1. **READY/REAR TRAVEL:** người di chuyển để cầu ở phía trên/hơi trước vai cầm vợt, thân chuyển sang tư thế nghiêng ngang.
2. **LOAD:** tay trái nâng hướng cầu, tay phải/vợt chuẩn bị phía sau; tải vào chân sau và hông.
3. **SWING/CONTACT:** chân sau đẩy, hông và vai xoay, khuỷu/tay vợt đi lên; vùng tiếp xúc được định nghĩa trên mặt dây vợt, phía trên hoặc hơi trước vai phải. **Timing contact phải do animation thử + đường cầu giả lập xác nhận**, không chốt bằng suy luận từ clip smash.
4. **FOLLOW/RECOVERY:** tay vợt đi tiếp có kiểm soát, chân sau chuyển lên trước theo biến thể scissor nếu action này được chọn, thân về trạng thái có thể di chuyển.

**Điểm cần đo trên rig:** vợt và cầu gặp nhau đúng thời điểm; đường cầu sau đánh bay về cuối sân đối phương; hai chân đổi trụ có thật và tiếp đất hợp lý; không dùng cú smash đã gửi rồi chỉ thay hướng cầu. **Rủi ro:** thiếu footage clear độc lập, nên card này là *BWF-derived design*, chưa thể được gắn nhãn “tái tạo chính xác Axelsen/Lee”.

## 4. Bước kế tiếp và cổng phê duyệt

**AF2 hoàn tất ở mức phương án có thể thử:** có sheet video cho ready/split và jump overhead, có motion card chuẩn BWF cho lunge/clear, với mọi khoảng trống được ghi rõ. Chưa đủ để nói animation game đạt chất lượng cao.

**Đề xuất milestone AF3 nhỏ:** tạo một rig người nam thuận tay phải đơn giản, thử một action *ready → split → tiến lưới thuận tay → lunge → hồi vị* trước; đồng thời làm **storyboard sáu pose** cho clear để xác nhận đường vợt/cầu. Deliverable đề xuất: tệp Blender nguồn, clip xem từ sau và bên, bảng mốc tiếp đất/contact, log lỗi, GLB thử xuất/nhập. Acceptance: không chân trượt rõ, không gối gãy/xuyên sàn, thân chuyển trọng tâm liên tục, vợt ở đúng vùng đón cầu, hồi vị có bước hợp lý; nếu thiếu các tiêu chí này đánh **FAIL** và chỉnh lại. Rủi ro: rig/retarget từ thư viện generic có thể sai chân trụ và mặt vợt; cần thiết kế hoặc cleanup thủ công.

AF3 là công đoạn sản xuất thử tiếp theo, tách khỏi nghiên cứu AF1–AF2. Chủ dự án đã yêu cầu dừng sau kế hoạch để duyệt, nên motion cards này là kết quả review trước khi bắt đầu Blender. Ông không cần thao tác phần mềm 3D.
