# Shuttle Arena 3D — Motion Reference bổ sung v0.2

Ngày 14/10/2026. Phạm vi AF1–AF2: xem ba file người dùng gửi, tuyển mẫu để thiết kế animation; **chưa tạo animation 3D hoặc chạy video mocap**. Mốc bên dưới tính theo **từng file**, không theo video YouTube gốc. Các khoảng được chọn sau khi xem chuỗi hình cách nhau 0,1–0,2 giây ở đoạn trọng tâm. Khoảng chạm cầu chỉ là ước lượng nếu cầu/vợt bị nhòe.

## Danh mục nguồn

| Mã | File nhận được | Thông số file | Góc quay và giá trị |
|---|---|---|---|
| S1 | `YTSave_Shorts_Media_YZqcmLyRnLg_Split-step-timing-exercise-badmintontraining_001_720p.mp4` | 12,17 giây; 720×1280; 30 fps danh nghĩa | Góc sau sân, toàn thân người áo xanh; có đối thủ và cầu. Dùng tham khảo phản ứng trong rally, nhưng chân xa và không luôn thấy rõ hai đế giày. |
| S2 | `YTSave_YouTube_Media_HDgv15AuJTs_Kỹ-Thuật-Tách-Bước-Split-Step-Trong-Cầu-Lông-Bí-Quyết-Di-Chuyển-Nhanh-Hiệu-Quả_001_720p.mp4` | 32,00 giây; 1280×720; 30 fps danh nghĩa | Video hướng dẫn từ chính diện, có cận cảnh chân lồng góc. Tốt cho hình dáng và thứ tự bài tập; có cắt dựng, không đồng nhất với nhịp rally. |
| S3 | `YTSave_Shorts_Media_4MmacECOc14_Overhead-smash-and-variations-l-shorts-short-badminton_001_1080p.mp4` | 17,37 giây; 1080×1920; xấp xỉ 59,94 fps danh nghĩa | Góc chéo sau/bên sân, thấy rõ người áo đen, vợt, chân và cầu ở một số thời điểm. Tốt hơn clip thi đấu trước cho dáng đánh trên cao; dòng chữ gọi là smash nhưng phải phân biệt nhãn video với kết quả nhìn thấy. |

FPS trên là metadata của file được gửi; không chứng minh tốc độ khung hình của bản quay gốc, có tăng tốc/chậm hoặc lặp frame hay không. Chưa xác minh quyền tái sử dụng footage/motion trong game hoặc đưa lên dịch vụ thứ ba. Hiện dùng làm **reference phân tích nội bộ**, chưa chấm đủ tiêu chí để phê duyệt mocap.

## S2 — split-step minh họa từ chính diện

**Đoạn ưu tiên 00:02,8–00:03,8 (ước lượng).** Người mặc áo đen đứng gần đường giữa khung. Quan sát: hai chân từ khoảng cách hẹp mở rộng sang hai bên, gối gập và hông hạ xuống; thân tiếp tục thấp khi chân mở rộng, rồi người dịch sang bên. Đoạn lồng góc cận chân xuất hiện sau đó giúp thấy hình dáng hai bàn chân mở rộng khi tiếp đất. Hình ảnh có cắt dựng và hiệu ứng, nên không lấy độ trễ trong clip để đặt timing gameplay.

| Mốc hành động | Quan sát được | Suy luận hoặc chưa xác nhận |
|---|---|---|
| READY ~00:02.8–00:03.0 | Tư thế hai chân tương đối gần, gối mềm, vợt thấp phía trước người. | Không suy ra tư thế thi đấu tối ưu từ bài hướng dẫn. |
| LOAD/OPEN ~00:03.0–00:03.4 | Hai chân mở rộng và thân hạ thấp; sau đó có dịch chuyển theo hướng bên. | Chưa xác định chính xác frame cả hai chân cùng rời mặt sân vì nhòe và tần suất lấy mẫu. |
| MOVE ~00:03.4–00:04.2 | Người bước khỏi tư thế mở chân theo một hướng. | Clip dạy kỹ thuật không chứng minh thời điểm split trùng cú chạm cầu của đối thủ. |
| CONTACT | N/A: đây là bài minh họa bước chân. | Không gắn mốc vợt chạm cầu. |
| RECOVERY | Đoạn bài tập bị cắt sang cảnh giải thích khác. | Không suy ra quỹ đạo hồi vị của một rally. |

**Lưu ý định dạng:** `00:03.4` nghĩa là 3,4 giây tính từ đầu file; các nhãn READY/LOAD/MOVE là nhãn phân tích. Bài tập cho hình dạng pose **split landing**, nhưng cần clip rally liên tục để chốt trigger và chuyển hướng.

## S1 — split-step trong rally và phản ứng hướng

**Đoạn ưu tiên 00:07,3–00:08,8 (ước lượng).** Người áo xanh ở sân gần. Quan sát: trước khi đối thủ phía xa hoàn thành pha đánh, người áo xanh bước chỉnh chân và vào tư thế hai chân mở; sau đó hông hạ xuống, trọng tâm thị giác dịch sang một bên, một chân duỗi rộng để với cầu, rồi người thu chân. Một số hình cho thấy gót hoặc một chân nhấc khỏi sàn, nhưng không thể xác nhận từ góc này chính xác hai chân cùng bật lên và cùng tiếp đất ở frame nào.

| Mốc hành động | Quan sát được | Suy luận hoặc chưa xác nhận |
|---|---|---|
| READY ~00:07.3–00:07.6 | Người áo xanh nhìn về phía đối thủ, vợt thấp và trước cơ thể; bàn chân điều chỉnh liên tục. | Không phải idle đứng bất động. |
| LOAD/SPLIT ~00:07.6–00:08.1 | Chân mở rộng hơn, thân hạ; chân có nhấc và đặt lại ngắn. | Nhịp này phù hợp với split-step trong bối cảnh rally, nhưng frame rời/chạm sàn tuyệt đối còn chưa rõ. |
| MOVE ~00:08.1–00:08.8 | Chuyển sang bước sang bên và thấp người để đón cầu. | Không xác nhận bằng clip này đây là chasse hay cross-step; cần góc chân rõ hơn. |
| CONTACT | Không định vị chắc mặt vợt chạm cầu. | N/A cho mục tiêu footwork. |
| RECOVERY | Sau động tác người đưa thân về gần vị trí chuẩn bị. | Không lấy tốc độ và khoảng cách tuyệt đối vì camera có phối cảnh. |

**Đọc chung S1 + S2:** S2 giúp nhìn thế chân khi mở; S1 cho thấy nó là một bước nối vào di chuyển trong rally. Không trộn timing của hai người ở hai clip thành một chuyển động duy nhất.

## S3 — chuỗi đánh trên cao, hướng ưu tiên smash/jump overhead

**Đoạn ưu tiên 00:01,2–00:02,6 (ước lượng).** Người áo đen ở nửa sân gần. Quan sát trực tiếp: chân lùi/chỉnh dưới đường cầu, thân xoay và ngả ra sau, tay không vợt nâng theo hướng cầu, tay vợt kéo lên phía sau đầu; tiếp đó người bật lên, vợt đi nhanh qua vùng trên đầu, thân gập/quay theo cú đánh, rồi chân chạm đất và người tiếp tục bước. Khu vực va chạm cầu/vợt rất nhanh và nhỏ trong ảnh nên mốc impact chỉ là **khoảng**, chưa khóa frame.

| Mốc hành động | Quan sát được | Suy luận hoặc chưa xác nhận |
|---|---|---|
| READY/ADJUST ~00:01.2–00:01.4 | Hai chân chỉnh chỗ đứng; mắt/thân hướng theo cầu, vợt chuẩn bị. | Không suy ra chân nào gánh lực nhiều hơn. |
| LOAD/ROTATE ~00:01.4–00:01.8 | Hông và vai xoay; tay không vợt nâng; tay vợt kéo lên sau/ngoài đầu; hai gối chuẩn bị đẩy. | Đây là các mốc lớn cần giữ cho silhouette 3D; góc khớp chính xác chưa đo. |
| TAKEOFF/SWING ~00:01.8–00:02.2 | Có thời điểm cả hai chân rời sân; tay vợt vung qua trên đầu, thân đổi hướng. | Impact **có thể** nằm trong khoảng 00:01.8–00:02.0, cần kiểm tra các frame nguồn đầy đủ và audio nếu muốn khóa contact. |
| FOLLOW-THROUGH ~00:02.0–00:02.4 | Tay vợt theo xuống, thân gập và quay; hai chân bắt đầu nhận lại trọng lượng trên sân. | Không xác nhận tốc độ đầu vợt từ motion blur. |
| RECOVERY ~00:02.4–00:03.0 | Người tiếp tục bước/chỉnh lại tư thế sau pha đánh. | Chưa chứng minh trở về ready đầy đủ trong một action đơn. |

**Nhãn kỹ thuật:** chữ trên video là “Overhead smash and variations”, và chuỗi hình có bật nhảy/vung mạnh trên cao. Ghi **ứng viên jump overhead/smash**, độ tin cậy trung bình; chưa xem đó là mẫu **forehand overhead clear** hoặc chứng minh quỹ đạo cầu cắm xuống bằng phép đo. File có thêm vài lượt đánh trên cao sau ~06 và ~12 giây để so sánh biến thể, nhưng không gộp các lượt này thành một động tác P0.

## Quyết định tuyển mẫu và việc tiếp theo

| Nhu cầu AF1–AF2 | Kết quả | Kế tiếp |
|---|---|---|
| Ready/split-step | Có mẫu tư thế rõ (S2) và bối cảnh rally (S1); **timing chính xác vẫn mở**. | Dùng hai clip làm reference tách riêng; nếu cần sự kiện chân chạm đất ở mức frame, xin một góc thấp/ít che khuất hoặc xem frame gốc theo chuỗi. |
| Lunge tiến lưới + recovery | **Chưa có clip đạt** trong ba file mới. | Tuyển một pha tiến tới góc trước sân rồi đạp chân về, trọn người trong 3–6 giây. |
| Forehand overhead clear | **Chưa có clip đạt**; S3 chủ yếu minh họa jump overhead. | Tuyển một cú clear có cầu bay cao về cuối sân và trọn nhịp chuẩn bị → đánh → hồi vị. |
| Smash | Có **ứng viên reference hình thể** S3. | Chỉ thử retarget sau khi xác định rig, quyền sử dụng và contact interval; không suy ra chất lượng animation từ video. |

### Hướng dẫn ngắn cho chủ dự án

Ông có thể tiếp tục gửi clip như lần này; **không cần dùng Blender**. Đoạn có ích nhất kế tiếp là **một cú clear hoặc lao lên lưới và hồi vị**, quay trọn người từ sau chéo hoặc bên hông, không cắt đúng lúc vung vợt/chạm cầu. Tôi sẽ chọn mốc và điền sheet. Sau khi ba loại reference cơ bản đủ chắc, mới lập đề xuất thử một chuyển động trên rig và trình ông duyệt trước công đoạn 3D.

**Trạng thái nghiệm thu:** sheet này mới chứng minh đã xem được các hình cần phân tích. Chưa đủ quyền, dữ liệu 3D hay kết quả kiểm chứng để tuyên bố mocap hoặc animation đạt chuẩn.
